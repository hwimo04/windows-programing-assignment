def calc(*args, op='+'):
    if op == '+':
        result = 0
        for num in args:
            result += num
        return result
    elif op == '*':
        result = 1
        for num in args:
            result *= num
        return result
    else:
        return "다른 연산자를 입력해주세요"


print(calc(1, 1, 4, op='+'))
print(calc(1, 2, op='*'))