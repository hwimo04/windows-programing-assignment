def min_max(num_list):
    if not num_list:
        return None, None

    min_val = num_list[0]
    max_val = num_list[0]

    for num in num_list:
        if num < min_val:
            min_val = num
        if num > max_val:
            max_val = num

    return (min_val, max_val)

if __name__ == "__main__":
    user_input = input("정수들을 공백으로 구분하여 입력하세요: ")

    numbers = list(map(int, user_input.split()))

    result = min_max(numbers)

    if result[0] is not None:
        print(f"입력된 리스트: {numbers}")
        print(f"가장 작은 값(min)과 큰 값(max) 튜플 반환 결과: {result}")
        print(f"최소값: {result[0]}, 최대값: {result[1]}")
    else:
        print("입력된 값이 없습니다.")