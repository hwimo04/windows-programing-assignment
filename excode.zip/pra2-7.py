import random

words = ['hangman', 'python', 'windows', 'homework', 'pratice']


def play_hangman():
    # 리스트의 길이값(len)을 기준으로 랜덤 인덱스 생성 후 단어 선택
    random_index = random.randint(0, len(words) - 1)
    word = words[random_index]

    guessed_letters = set()
    trials_left = 6

    print("\n--- 행맨 게임 시작 ---")

    while trials_left > 0:
        current_display = ''.join([ch if ch in guessed_letters else '_' for ch in word])
        print(f"단어: {current_display}")

        if '_' not in current_display:
            print("Good Job!")
            return

        guess = input("글자를 입력하세요: ").strip().lower()

        if len(guess) != 1 or not guess.isalpha():
            print("한 글자의 영문자를 입력해주세요.")
            continue

        if guess in guessed_letters:
            print("이미 시도한 글자입니다.")
            continue

        guessed_letters.add(guess)

        if guess in word:
            print(f"맞았습니다! ('{guess}')")
        else:
            trials_left -= 1
            print(f"Nope! {trials_left} trials left")

    print("Fail!")
    print(f"정답 단어는 '{word}'였습니다.")


while True:
    play_hangman()
    replay = input("\n게임을 계속 하시겠습니까? (y/n): ").strip().lower()
    if replay != 'y':
        print("게임을 종료합니다.")
        break