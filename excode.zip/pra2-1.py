list1 = [1,0,1]
list2 = [1,1,2]
sum = 0

for num in range(len(list1)):
    sum += list1[num] * list2[num]

print(f"{list1}* {list2} = {sum}")

