import math

a, b, c = 3, 4, 5
result1 = 1 / (1 + a / b + c)
print(f"1번 결과: {result1}")

a, b, c = 1, 1, -6
root1 = (-b + math.sqrt(b**2 - 4 * a * c)) / (2 * a)
root2 = (-b - math.sqrt(b**2 - 4 * a * c)) / (2 * a)
print(f"2번 결과 (두 근): {root1}, {root2}")

r = 5
area = math.pi * (r ** 2)
print(f"3번 결과 (원의 면적): {area}")

beta = 2.0
g = 3.2
result4 = beta * math.exp(-g)
print(f"4번 결과: {result4}")

x = 0
mu = 1.5
rho = 2.0

term1 = 1 / math.sqrt(2 * math.pi * rho)
exponent = ((x - mu) ** 2) / (2 * (rho ** 2))
result5 = term1 * math.exp(exponent)
print(f"5번 결과: {result5}")