while True:
    filename = input("파일명을 입력해주세요 (종료하려면 q 입력): ")

    if filename == 'q':
        print("프로그램을 종료합니다.")
        break

    try:
        with open(filename, 'r') as f:
            lines = f.readlines()

        sav_filename = filename + ".sav"

        with open(sav_filename, 'w') as f_sav:
            num = 1
            for line in lines:
                formatted_line = f"{num} {line}"
                print(formatted_line, end='')
                f_sav.write(formatted_line)
                num += 1

        print(f"\n[성공] '{sav_filename}' 파일로 저장되었습니다.\n")
        break

    except FileNotFoundError:
        print("찾을 수 없는 파일입니다. 다시 입력해주세요.\n")