while True:
    filename = input("파일명을 입력해주세요 (종료하려면 q 입력): ")

    if filename == 'q':
        print("프로그램을 종료합니다.")
        break

    try:
        with open(filename, 'r') as f:
            lines = f.readlines()

        line_count = len(lines)

        char_count = 0
        word_count = 0

        for line in lines:
            char_count += len(line.replace(' ', '').replace('\n', ''))
            words = line.split()
            word_count += len(words)

        print(f"characters : {char_count}")
        print(f"words      : {word_count}")
        print(f"lines      : {line_count}")
        break

    except FileNotFoundError:
        print("찾을 수 없는 파일입니다. 다시 입력해주세요.\n")