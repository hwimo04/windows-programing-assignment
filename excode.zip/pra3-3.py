def count_vowel(text):
    vowels = "aeiouAEIOU"  # 대소문자 모음 정의
    count = 0

    for char in text:
        if char in vowels:
            count += 1

    return count


# 사용자로부터 문자열을 입력받아 테스트하는 프로그램
if __name__ == "__main__":
    user_string = input("문자열을 입력하세요: ")

    result = count_vowel(user_string)

    print(f"입력된 문자열: {user_string}")
    print(f"모음의 개수: {result}")