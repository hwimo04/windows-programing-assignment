for n in range(1, 101):  # 1부터 100까지의 자연수 n[cite: 28]
    if n % 2 == 0:
        print(f"{n}은 짝수입니다")
    else:
        print(f"{n}은 홀수입니다")