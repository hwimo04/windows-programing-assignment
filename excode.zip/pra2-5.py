year = input("년도를 입력해주세요: ")
year = int(year)

if year%100==0:
    if year%400==0:
        print(f"{year}년은 윤년입니다")
    else:
        print(f"{year}년은 평년입니다")
elif year % 4 == 0:
    print(f"{year}년은 윤년입니다")

else:
    print(f"{year}년은 윤년과 평년이 아닙니다")