st_dict = {}
while True:
    n = input("list : 명단 시스템\noutput : 출력 시스템\nquit: 프로그램 종료\n값을 입력해주세요: ")
    n = str(n)
    if n == "list":
        while True:
            id = input("학생의 학번: ")
            id = int(id)

            name = input("학생의 이름: ")
            name = str(name)

            if id==0:
                break
            elif name=="None":
                break
            else:
                st_dict[id] = name
        print(st_dict)
    elif n == "output":
        while True:
            id_input = input("찾으려는 학생의 학번을 입력해주세요(종료 시 '0'입력): ")
            id_input = int(id_input)
            if id_input in st_dict:
                print(st_dict[id_input])
            elif id_input == 0:
                break
            else:
                print("not found!")
    elif n == "quit":
        break